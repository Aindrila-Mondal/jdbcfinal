package com.cg.bankaccount.bean;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;

public class Transaction
{
	private String transactiontype;
	private double transactionamt;
	private Date date;
	private Time time;

	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public double getTransactionamt() {
		return transactionamt;
	}
	public void setTransactionamt(double transactionamt) {
		this.transactionamt = transactionamt;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date2) {
		this.date = date2;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Transaction [transactiontype=" + transactiontype + ", transactionamt=" + transactionamt + ", date="
				+ date + ", time=" + time + "]";
	}
	
	
}