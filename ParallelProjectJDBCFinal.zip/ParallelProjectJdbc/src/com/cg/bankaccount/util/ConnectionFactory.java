package com.cg.bankaccount.util;



import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.bankaccountexceptions.BankExceptions;


public class ConnectionFactory 
{
	private static ConnectionFactory signtonobj;
	
	public static ConnectionFactory getSigntonObj()
	{
		if(signtonobj==null)
			signtonobj=new ConnectionFactory();
		
		return signtonobj;
	}
	
	
	
	
	
	
public Connection getConnection() throws BankExceptions
{
	Connection con=null;
	try {
		
		
		//FileInputStream fs=new FileInputStream("resource/product.properties");
		//Properties prop=new Properties();
		//prop.load(fs);;
		String driver="oracle.jdbc.driver.OracleDriver";//prop.getProperty("db.driver");
		String url="jdbc:oracle:thin:@localhost:1521:XE";//prop.getProperty("db.url");
		String user="system";//rop.getProperty("db.user");
		String pass="Capgemini123";//prop.getProperty("db.pass");
		Class.forName(driver);
		
		con=DriverManager.getConnection(url, user, pass);
		
	}catch(ClassNotFoundException | SQLException e)
	{
		throw new BankExceptions("Some problem in connection,or database");
	}
	return con;
}
}