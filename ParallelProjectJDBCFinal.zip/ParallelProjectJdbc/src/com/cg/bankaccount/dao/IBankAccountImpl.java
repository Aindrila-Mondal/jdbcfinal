package com.cg.bankaccount.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import com.cg.bankaccount.bean.Account;
import com.cg.bankaccount.bean.Transaction;
import com.cg.bankaccount.util.ConnectionFactory;
import com.cg.bankaccountexceptions.BankExceptions;



public class IBankAccountImpl implements IBankAccountDao
{
	private PreparedStatement ps=null;
	private Connection con=null;
    private ResultSet rs=null;
    
	@Override
	public void createAccount(long AccNo, String Name, Double balance) throws BankExceptions 
	{
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new BankExceptions("connection not established");
			}
		ps=con.prepareStatement(QueryMapping.INSERT_QUERY);
		ps.setLong(1, AccNo);
		ps.setString(2, Name);
		ps.setDouble(3, balance);
		ps.executeUpdate();
		
		ps=con.prepareStatement(QueryMapping.RETRIEVE_QUERY);
		ps.setString(1,Name);
		 rs=ps.executeQuery();
		if(rs.next())
		{
			
			System.out.println("Account created successfully"+rs.getInt(1));
		}
		}catch(Exception ex)
	    {
			throw new BankExceptions("problem message"+ex.getMessage());
			
        }
	    finally 
	    {
	    	try {
	    	if(con==null||ps==null||rs==null)
	    	{
	    		throw new BankExceptions("connection not established");
	    		
	    	}
	    	con.close();
	    	ps.close();
	    	rs.close();
	    	
	    	}
	    	catch(SQLException e)
	    	{
	    		throw new BankExceptions("problem in database"+e.getMessage());
	    	}
	    	catch(Exception e)
	    	{
	    		throw new BankExceptions("problem in database"+e.getMessage());
	    	}
	    }
	
		
		
	}

	@Override
	public void showBalance(long AccNo) throws  BankExceptions
	{try {
		con=ConnectionFactory.getSigntonObj().getConnection();
		if(con==null) {
			throw new BankExceptions("connection not established");
		}
		
		ps=con.prepareStatement(QueryMapping.UPDATE_QUERY);
		ps.setLong(1, AccNo);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			double balance=rs.getDouble(1);
		}
	}catch(Exception ex)
    {
		throw new BankExceptions("problem message"+ex.getMessage());
		
    }
    finally 
    {
    	try {
    	if(con==null||ps==null||rs==null)
    	{
    		throw new BankExceptions("connection not established");
    		
    	}
    	con.close();
    	ps.close();
    	rs.close();
    	
    	}
    	catch(SQLException e)
    	{
    		throw new BankExceptions("problem in database"+e.getMessage());
    	}
    	catch(Exception e)
    	{
    		throw new BankExceptions("problem in database"+e.getMessage());
    	}
    }
	  
	}

	@Override
	public void deposit(long AccNo,double deposit) throws BankExceptions
	{
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new BankExceptions("connection not established");
			}
		ps=con.prepareStatement(QueryMapping.RETRIEVAL_QUERY);
		ps.setLong(1, AccNo);
		ResultSet rs=ps.executeQuery();
		double bal1=0;
		if(rs.next())
		{
			double balance=rs.getDouble(3);
			bal1=balance+deposit;
			}
		
		ps=con.prepareStatement(QueryMapping.BALANCE_QUERY);
		ps.setDouble(1, bal1);
		ps.setLong(2, AccNo);
		ps.executeUpdate();
		
	
		
		ps=con.prepareStatement(QueryMapping.INSERTTRANSACTION_QUERY);
		ps.setString(1,"credit");
		ps.setDouble(2,deposit);
		ps.setDate(3,Date.valueOf(LocalDate.now()));
		String t=LocalTime.now()+"";
		ps.setString(4,t);
		ps.executeUpdate();
		}catch(Exception ex)
	    {
			throw new BankExceptions("problem message"+ex.getMessage());
			
	    }	
		  finally 
		    {
		    	try {
		    	if(con==null||ps==null||rs==null)
		    	{
		    		throw new BankExceptions("connection not established");
		    		
		    	}
		    	con.close();
		    	ps.close();
		    	rs.close();
		    	
		    	}
		    	catch(SQLException e)
		    	{
		    		throw new BankExceptions("problem in database"+e.getMessage());
		    	}
		    	catch(Exception e)
		    	{
		    		throw new BankExceptions("problem in database"+e.getMessage());
		    	}
		    }
			  
				
	}
		
	@Override
	public void withdraw(long AccNo,double withdraw) throws BankExceptions
	{
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new BankExceptions("connection not established");
			}
		ps=con.prepareStatement(QueryMapping.RETRIEVAL_QUERY);
		ps.setLong(1, AccNo);
		ResultSet rs=ps.executeQuery();
		double bal1=0;
		if(rs.next())
		{
			double balance=rs.getDouble(3);
			bal1=balance-withdraw;
			}
		
		ps=con.prepareStatement(QueryMapping.UPDATE_QUERY);
		ps.setDouble(1, bal1);
		ps.setLong(2, AccNo);
		ps.executeUpdate();
	   
	
		
		ps=con.prepareStatement(QueryMapping.INSERTTRANSACTION_QUERY);
		        
		        ps.setDouble(1,withdraw);
				ps.setString(2,"debit");
				ps.setDate(3,Date.valueOf(LocalDate.now()));
				
				ps.setTime(4,Time.valueOf(LocalTime.now()));
				ps.executeUpdate();
				
		}catch(Exception ex)
	    {
			throw new BankExceptions("problem message"+ex.getMessage());
			
	    }	
		  finally 
		    {
		    	try {
		    	if(con==null||ps==null||rs==null)
		    	{
		    		throw new BankExceptions("connection not established");
		    		
		    	}
		    	con.close();
		    	ps.close();
		    	rs.close();
		    	
		    	}
		    	catch(SQLException e)
		    	{
		    		throw new BankExceptions("problem in database"+e.getMessage());
		    	}
		    	catch(Exception e)
		    	{
		    		throw new BankExceptions("problem in database"+e.getMessage());
		    	}
		    }
	}

	
	@Override
	public void fundtransfer(long AccNo1, long AccNo2, double fundamt) throws BankExceptions
	{
		
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new BankExceptions("connection not established");
			}
		ps=con.prepareStatement(QueryMapping.RETRIEVAL_QUERY);
		ps.setLong(1, AccNo1);
		ResultSet rs2=ps.executeQuery();
		double f=0;
		if(rs2.next())
		{
			double balance=rs2.getDouble(3);
			f=balance-fundamt;
			}
		
		ps=con.prepareStatement(QueryMapping.UPDATE_QUERY);
		ps.setDouble(1, f);
		ps.setLong(2, AccNo1);
		ps.executeUpdate();
		
		ps=con.prepareStatement(QueryMapping.RETRIEVAL_QUERY);
		ps.setLong(1, AccNo2);
		ResultSet rs3=ps.executeQuery();
		double f1=0;
		if(rs3.next())
		{
			double balance=rs3.getDouble(3);
			f1=balance+fundamt;
		}
		
		ps=con.prepareStatement(QueryMapping.UPDATE_QUERY);
		ps.setDouble(1, f1);
		ps.setLong(2, AccNo1);
		ps.executeUpdate();
		
     }catch(Exception ex)
	    {
			throw new BankExceptions("problem message"+ex.getMessage());
			
	    }	
		  finally 
		    {
		    	try {
		    	if(con==null||ps==null||rs==null)
		    	{
		    		throw new BankExceptions("connection not established");
		    		
		    	}
		    	con.close();
		    	ps.close();
		    	rs.close();
		    	
		    	}
		    	catch(SQLException e)
		    	{
		    		throw new BankExceptions("problem in database"+e.getMessage());
		    	}
		    	catch(Exception e)
		    	{
		    		throw new BankExceptions("problem in database"+e.getMessage());
		    	}
		    }
	}
	
	@Override
	public Account display() throws BankExceptions {
		// TODO Auto-generated method stub
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new BankExceptions("connection not established");
			}
		Account acc=new Account();
		ps=con.prepareStatement(QueryMapping.DISPLAYACCOUNT_QUERY);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			acc.setAccNo((rs.getLong(1)));
			acc.setName(rs.getString(2));
			acc.setBalance((rs.getDouble(3)));
		}
		return acc;
	
	}catch(Exception ex)
    {
		throw new BankExceptions("problem message"+ex.getMessage());
		
    }	
	  finally 
	    {
	    	try {
	    	if(con==null||ps==null||rs==null)
	    	{
	    		throw new BankExceptions("connection not established");
	    		
	    	}
	    	con.close();
	    	ps.close();
	    	rs.close();
	    	
	    	}
	    	catch(SQLException e)
	    	{
	    		throw new BankExceptions("problem in database"+e.getMessage());
	    	}
	    	catch(Exception e)
	    	{
	    		throw new BankExceptions("problem in database"+e.getMessage());
	    	}
	    }
	}

	@Override
	public Transaction display1() throws BankExceptions {
		// TODO Auto-generated method stub
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new BankExceptions("connection not established");
			}
		Transaction tran=new Transaction();
		ps=con.prepareStatement(QueryMapping.DISPLAYTRANSACTION_QUERY);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			
			tran.setTransactionamt(rs.getDouble(1));
			tran.setTransactiontype(rs.getString(2));
			tran.setDate(rs.getDate(3));
			tran.setTime(rs.getTime(4));
		}
		return tran;
	}catch(Exception ex)
    {
		throw new BankExceptions("problem message"+ex.getMessage());
		
    }	
	  finally 
	    {
	    	try {
	    	if(con==null||ps==null||rs==null)
	    	{
	    		throw new BankExceptions("connection not established");
	    		
	    	}
	    	con.close();
	    	ps.close();
	    	rs.close();
	    	
	    	}
	    	catch(SQLException e)
	    	{
	    		throw new BankExceptions("problem in database"+e.getMessage());
	    	}
	    	catch(Exception e)
	    	{
	    		throw new BankExceptions("problem in database"+e.getMessage());
	    	}
	    }
	}
}
