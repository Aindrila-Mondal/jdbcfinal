package com.cg.bankaccount.dao;

public class QueryMapping {
	static final String  INSERT_QUERY="insert into Account values(?,?,?)";
	static final String  RETRIEVE_QUERY="select * from Account where Name=?";
	static final String  BALANCE_QUERY="select balance from Account where AccNo=?";
	static final String  RETRIEVAL_QUERY="select * from Account where AccNo=?";
	static final String  INSERTTRANSACTION_QUERY="insert into Transaction values(?,?,?.?)";
	static final String  UPDATE_QUERY="update Account set balance=? where AccNo=?";
	static final String  DISPLAYACCOUNT_QUERY="select * from Account ";
	static final String  DISPLAYTRANSACTION_QUERY="select * from Transaction ";
}
