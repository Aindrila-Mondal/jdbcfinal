package com.cg.bankaccount.service;

import java.sql.SQLException;

import com.cg.bankaccount.bean.Account;
import com.cg.bankaccount.bean.Transaction;
import com.cg.bankaccount.dao.IBankAccountDao;
import com.cg.bankaccount.dao.IBankAccountImpl;
import com.cg.bankaccountexceptions.BankExceptions;

public class IBankAccountServiceImpl implements IBankAccountService
{
	
    IBankAccountDao dao=new IBankAccountImpl();
	@Override
	public void createAccount(long AccNo, String Name, Double balance) throws BankExceptions{
		dao.createAccount(AccNo, Name, balance);
	}

	@Override
	public void showBalance(long AccNo) throws BankExceptions
	{
		// TODO Auto-generated method stub
		dao.showBalance(AccNo);
	}

	@Override
	public void deposit(long AccNo, double deposit)throws BankExceptions
	{
		// TODO Auto-generated method stub
		dao.deposit(AccNo, deposit);
	}

	@Override
	public void withdraw(long AccNo, double withdraw) throws  BankExceptions{
		// TODO Auto-generated method stub
		dao.withdraw(AccNo, withdraw);
	}

	@Override
	public void fundtransfer(long AccNo1, long AccNo2, double fundamt) throws BankExceptions {
		// TODO Auto-generated method stub
		dao.fundtransfer(AccNo1, AccNo2, fundamt);
	}


	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		String regex="^[a-zA-Z\\s]+$";
		if(name.matches(regex))
			return true;
		return false;
	}

	@Override
	public boolean validateAccountNumber(long AccNo) {
		// TODO Auto-generated method stub
		String number=String.valueOf(AccNo);
		String regex1="^[0-9]{6}$";
		
		if(number.matches(regex1))
		return true;
		return false;
	}

	@Override
	public Account display() throws BankExceptions{
		// TODO Auto-generated method stub
		return dao.display();
	}

	@Override
	public Transaction display1() throws BankExceptions {
		// TODO Auto-generated method stub
		return dao.display1();
	}

}



