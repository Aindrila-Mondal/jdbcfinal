package com.cg.bankaccount.service;

import java.sql.SQLException;

import com.cg.bankaccount.bean.Account;
import com.cg.bankaccount.bean.Transaction;
import com.cg.bankaccountexceptions.BankExceptions;

public interface IBankAccountService 
{
	public void createAccount(long AccNo,String Name,Double balance) throws BankExceptions;
	public void showBalance(long AccNo) throws BankExceptions;
	public void  deposit(long AccNo,double deposit) throws BankExceptions;
	public void  withdraw(long AccNo,double withdraw) throws BankExceptions;
	public void  fundtransfer(long AccNo1,long AccNo2,double fundamt) throws BankExceptions;
	public Account  display() throws BankExceptions;
	public Transaction display1() throws BankExceptions;
	public boolean validateName(String name);
	public boolean validateAccountNumber(long AccNo);

}
