package com.cg.bankaccount.ui;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

import com.cg.bankaccount.bean.Account;
import com.cg.bankaccount.bean.Transaction;
import com.cg.bankaccount.service.IBankAccountService;
import com.cg.bankaccount.service.IBankAccountServiceImpl;
import com.cg.bankaccountexceptions.BankExceptions;

public class AccountMain
{
public static void main(String[] args) 
{
	IBankAccountService service=new IBankAccountServiceImpl();      //creating object of IBankService
	Scanner sc=new Scanner(System.in);                //creating Scanner class object to input user data
	while(true)
	{
		System.out.println("1.create account");
		System.out.println("2.show balance");
		System.out.println("3.deposit into account");
		System.out.println("4.withdraw from account");
		System.out.println("5.fund transfer");
		System.out.println("6.display account");
		System.out.println("7.display transaction");
		System.out.println("8.exit");
		int opt=sc.nextInt();
		switch(opt)
		{
		case 1:   Random obj=new Random(); //generating account no randomly
		          long accno=obj.nextLong();
		          String  name;           
		          do {
			      System.out.println("enter name");
			      name=sc.next();
		          }while(!service.validateName(name));    //checking validation method for name
		          
		         
			      double balance=0;
					try {
						service.createAccount(accno, name,balance);
					} catch (BankExceptions e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					      break;
			      
		case 2:   System.out.println("enter acc no to show balance");	  
		          long accno1=sc.nextLong();
					try {
						service.showBalance(accno1);
					} catch (BankExceptions e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				          break;
		          
		case 3:   System.out.println("enter amount to be deposited"); 
		          double deposit=sc.nextDouble();
		          System.out.println("enter acc no to deposit money");	  
		          long accno2=sc.nextLong();
					try {
						service.deposit(accno2, deposit);
					} catch (BankExceptions e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				          break;
		          
		case 4:   System.out.println("enter amount to be withdrawn"); 
			      double withdraw=sc.nextDouble();
			      System.out.println("enter acc no to withdraw money");	  
			      long accno5=sc.nextLong();
					try {
						service.withdraw(accno5, withdraw);
					} catch (BankExceptions e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					      break;    
					          
		          
		          
			case 5:     System.out.println("enter amount to be transfered"); 
				        double fundamt=sc.nextDouble();
				        System.out.println("enter acc no from where  money to be transfered");	  
				        long accno3=sc.nextLong();  
				        System.out.println("enter acc no where  money to be transfered");	  
				        long accno4=sc.nextLong();  
						try {
							service.fundtransfer(accno3, accno4, fundamt);
						} catch (BankExceptions e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						        break;
			        
		case 6:   
					try {
						Account acc = service.display();
					
				           System.out.println(acc);
					} catch (BankExceptions e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	 
						   break;
		case 7:   
					try {
						 Transaction tran = service.display1();
					  
				           System.out.println(tran);
					} catch (BankExceptions e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
				           break;
				 
		case 8:    System.out.println("terminated");
		           System.exit(0);                                   //to exit system
		           sc.close();                                       //closing resource
		default:  System.out.println("wrong choice");			
		
		}  
	}
}
}
