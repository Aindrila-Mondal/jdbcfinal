package com.cg.bankaccountexceptions;

public class BankExceptions extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BankExceptions(String msg)
	{
		super(msg);
	}
}
